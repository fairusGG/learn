#pragma once

void runTcpServer(unsigned short port);
void runTcpClient(unsigned short port);
